
import { useEffect, useState } from 'react';
import axios from 'axios';

export default function Orders() {
  const [orders, setOrders] = useState([]);
  const token = localStorage.getItem('token');

  useEffect(() => {
    axios.get('/api/orders', { headers: { Authorization: `Bearer ${token}` } })
      .then(res => setOrders(res.data));
  }, []);

  return (
    <div className="p-4">
      <h2 className="text-xl mb-4">Your Orders</h2>
      <ul>
        {orders.map((order: any) => (
          <li key={order.id} className="border p-2 mb-2 rounded">
            <div><strong>ID:</strong> {order.id}</div>
            <div><strong>Status:</strong> {order.status}</div>
            <div><strong>Total:</strong> ${order.totalAmount}</div>
          </li>
        ))}
      </ul>
    </div>
  );
}
