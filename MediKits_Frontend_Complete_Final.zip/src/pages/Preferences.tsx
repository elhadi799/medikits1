
import { useState, useEffect } from 'react';
import axios from 'axios';

export default function Preferences() {
  const [layout, setLayout] = useState('grid');
  const [theme, setTheme] = useState('light');
  const userId = localStorage.getItem('userId');

  const savePreferences = async () => {
    await axios.post(`/api/ui/preferences/${userId}`, { layout, theme });
    alert('Preferences saved!');
  };

  useEffect(() => {
    axios.get(`/api/ui/preferences/${userId}`).then(res => {
      if (res.data?.preferences) {
        setLayout(res.data.preferences.layout);
        setTheme(res.data.preferences.theme);
      }
    });
  }, []);

  return (
    <div className="p-4">
      <h2 className="text-xl mb-2">Personalization</h2>
      <label className="block mb-2">
        Layout:
        <select value={layout} onChange={e => setLayout(e.target.value)} className="ml-2 border p-1">
          <option value="grid">Grid</option>
          <option value="list">List</option>
        </select>
      </label>
      <label className="block mb-4">
        Theme:
        <select value={theme} onChange={e => setTheme(e.target.value)} className="ml-2 border p-1">
          <option value="light">Light</option>
          <option value="dark">Dark</option>
        </select>
      </label>
      <button className="bg-blue-600 text-white px-4 py-2" onClick={savePreferences}>Save</button>
    </div>
  );
}
