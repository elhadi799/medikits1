
import { useEffect, useState } from 'react';
import axios from 'axios';

export default function Recommendations() {
  const [kits, setKits] = useState([]);
  const userId = localStorage.getItem('userId');
  const token = localStorage.getItem('token');

  useEffect(() => {
    axios.post('/api/ai/recommend-products/' + userId, {}, {
      headers: { Authorization: `Bearer ${token}` }
    }).then(res => setKits(res.data.recommended || []));
  }, []);

  return (
    <div className="p-4">
      <h2 className="text-xl mb-4">Recommended for You</h2>
      <ul className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {kits.map((kit: any) => (
          <li key={kit.id} className="border p-4 rounded shadow">{kit.name}</li>
        ))}
      </ul>
    </div>
  );
}
