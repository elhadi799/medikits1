
import { useState } from 'react';

export default function Cart() {
  const [cart, setCart] = useState<any[]>(([]));

  const handleCheckout = () => {
    alert('Checkout placeholder - integrate with /orders');
  };

  return (
    <div className="p-4">
      <h2 className="text-xl mb-2">Your Cart</h2>
      <ul className="mb-4">
        {cart.length === 0 ? (
          <p>No items yet</p>
        ) : (
          cart.map((item, index) => (
            <li key={index} className="border p-2 mb-2 rounded">{item.name}</li>
          ))
        )}
      </ul>
      <button className="bg-green-600 text-white px-4 py-2" onClick={handleCheckout}>
        Checkout
      </button>
    </div>
  );
}
