
import { useEffect, useState } from 'react';
import axios from 'axios';

export default function Dashboard() {
  const [kits, setKits] = useState([]);
  const token = localStorage.getItem('token');

  useEffect(() => {
    axios.get('/api/kits', { headers: { Authorization: `Bearer ${token}` } })
      .then(res => setKits(res.data))
      .catch(() => console.log("Error fetching kits"));
  }, []);

  return (
    <div className="p-4">
      <h1 className="text-2xl mb-4">Welcome to MediKits 2.0</h1>
      <h2 className="text-xl mb-2">Available Kits</h2>
      <ul className="space-y-2">
        {kits.map((kit: any) => (
          <li key={kit.id} className="p-2 border rounded">{kit.name}</li>
        ))}
      </ul>
    </div>
  );
}
