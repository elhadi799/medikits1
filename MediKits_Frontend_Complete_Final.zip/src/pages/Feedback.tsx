
import { useState } from 'react';
import axios from 'axios';

export default function Feedback() {
  const [text, setText] = useState('');
  const [result, setResult] = useState<any>(null);

  const analyze = async () => {
    const res = await axios.post('/api/ai/sentiment', { text });
    setResult(res.data);
  };

  return (
    <div className="p-4">
      <h2 className="text-xl mb-2">Leave Feedback</h2>
      <textarea className="border p-2 w-full mb-2" rows={4} value={text} onChange={e => setText(e.target.value)} />
      <button className="bg-blue-600 text-white px-4 py-2 mb-4" onClick={analyze}>Analyze</button>
      {result && (
        <div className="bg-gray-100 p-4 rounded">
          <p><strong>Sentiment Score:</strong> {result.score}</p>
          <p><strong>Emotion:</strong> {result.emotion}</p>
        </div>
      )}
    </div>
  );
}
