
import { useEffect, useState } from 'react';
import axios from 'axios';

export default function AdminTools() {
  const [tools, setTools] = useState<any>({});

  useEffect(() => {
    const fetchData = async () => {
      const churn = await axios.get('/api/ai/churn-risk/1');
      const bundles = await axios.get('/api/ai/bundle-suggestions');
      const loyalty = await axios.get('/api/ai/loyalty-tier/1');
      const fraud = await axios.get('/api/ai/fraud-signals/1');
      const alerts = await axios.get('/api/ai/kit-alerts');
      const targeting = await axios.get('/api/ai/campaign-targeting');
      const ab = await axios.get('/api/ai/ab-test-result');

      setTools({
        churn: churn.data,
        bundles: bundles.data,
        loyalty: loyalty.data,
        fraud: fraud.data,
        alerts: alerts.data,
        targeting: targeting.data,
        ab: ab.data
      });
    };
    fetchData();
  }, []);

  return (
    <div className="p-4">
      <h2 className="text-2xl mb-4">Admin AI Tools</h2>
      <pre className="bg-gray-100 p-4 text-sm rounded overflow-auto">{JSON.stringify(tools, null, 2)}</pre>
    </div>
  );
}
