
import { useState } from 'react';
import axios from 'axios';

export default function AdminKitEditor() {
  const [name, setName] = useState('');
  const [category, setCategory] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');

  const createKit = async () => {
    await axios.post('/api/kits', {
      name, category, description, price: parseFloat(price)
    });
    alert('Kit created!');
  };

  return (
    <div className="p-4">
      <h2 className="text-xl mb-4">Add New Kit</h2>
      <input className="border p-2 w-full mb-2" placeholder="Name" value={name} onChange={e => setName(e.target.value)} />
      <input className="border p-2 w-full mb-2" placeholder="Category" value={category} onChange={e => setCategory(e.target.value)} />
      <textarea className="border p-2 w-full mb-2" placeholder="Description" value={description} onChange={e => setDescription(e.target.value)} />
      <input className="border p-2 w-full mb-2" placeholder="Price" value={price} onChange={e => setPrice(e.target.value)} />
      <button className="bg-green-600 text-white px-4 py-2" onClick={createKit}>Save Kit</button>
    </div>
  );
}
