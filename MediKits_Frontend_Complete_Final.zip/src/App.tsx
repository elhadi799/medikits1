
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import Recommendations from './pages/Recommendations';
import Feedback from './pages/Feedback';
import AdminTools from './pages/AdminTools';
import Cart from './pages/Cart';
import Orders from './pages/Orders';
import Preferences from './pages/Preferences';
import AdminKitEditor from './pages/AdminKitEditor';

export default function App() {
  return (
    <BrowserRouter>
      <nav className="bg-white shadow p-4 flex gap-4 flex-wrap">
        <Link to="/">Dashboard</Link>
        <Link to="/recommendations">Recommendations</Link>
        <Link to="/feedback">Feedback</Link>
        <Link to="/cart">Cart</Link>
        <Link to="/orders">Orders</Link>
        <Link to="/preferences">Preferences</Link>
        <Link to="/admin">Admin Tools</Link>
        <Link to="/admin/kits">Add Kit</Link>
        <Link to="/login" className="ml-auto">Login</Link>
      </nav>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/recommendations" element={<Recommendations />} />
        <Route path="/feedback" element={<Feedback />} />
        <Route path="/cart" element={<Cart />} />
        <Route path="/orders" element={<Orders />} />
        <Route path="/preferences" element={<Preferences />} />
        <Route path="/admin" element={<AdminTools />} />
        <Route path="/admin/kits" element={<AdminKitEditor />} />
      </Routes>
    </BrowserRouter>
  );
}
