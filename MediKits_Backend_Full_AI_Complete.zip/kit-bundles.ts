
import express from 'express';

const router = express.Router();

const kitsDb = [
  {
    id: 'trauma_kit',
    name: 'Emergency Trauma Kit',
    category: 'Trauma',
    popularityScore: 4.7
  },
  {
    id: 'burn_kit',
    name: 'Burn Recovery Kit',
    category: 'Burn',
    popularityScore: 4.6
  },
  {
    id: 'ortho_kit',
    name: 'Orthopedic Support Kit',
    category: 'Orthopedic',
    popularityScore: 4.5
  },
  {
    id: 'cosmetic_kit',
    name: 'Post-Cosmetic Care Kit',
    category: 'Cosmetic',
    popularityScore: 4.2
  }
];

router.get('/kits/bundles', (req, res) => {
  const topKits = kitsDb.sort((a, b) => b.popularityScore - a.popularityScore).slice(0, 3);
  res.json({ bundledKits: topKits });
});

export default router;
