
import express from 'express';
import { storage } from './storage';

const router = express.Router();

// Simulated CSV or JSON exports

router.get('/export/sales', async (req, res) => {
  const report = await storage.getSalesReport(new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), new Date());
  res.json(report);
});

router.get('/export/behavior', async (req, res) => {
  const mockData = [
    { userId: 'user1', avgSessionTime: 7.2, pageViews: 14 },
    { userId: 'user2', avgSessionTime: 3.9, pageViews: 8 }
  ];
  res.json(mockData);
});

router.get('/export/ai-decisions', async (req, res) => {
  const mockLogs = [
    { type: 'forecasting', confidence: 0.87, description: '30-day forecast' },
    { type: 'sentiment', confidence: 0.91, description: 'Detected positive tone' }
  ];
  res.json(mockLogs);
});

export default router;
