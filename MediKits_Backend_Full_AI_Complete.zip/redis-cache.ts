
const cache: Record<string, { data: any; expires: number }> = {};

export function setCache(key: string, data: any, ttlSeconds = 60): void {
  const expires = Date.now() + ttlSeconds * 1000;
  cache[key] = { data, expires };
}

export function getCache(key: string): any | null {
  const cached = cache[key];
  if (!cached || cached.expires < Date.now()) {
    return null;
  }
  return cached.data;
}
