export { IStorage, storage } from "./memory-storage.js";

// Mocked storage handlers for new routes
export const logFeedback = async ({ userId, productId, feedbackText, sentiment, createdAt }) => {
  console.log(`[Feedback] ${userId} on ${productId}: ${feedbackText} (${sentiment.label})`);
};

export const logAbTestResult = async ({ testId, userId, variant, result, timestamp }) => {
  console.log(`[A/B Test] ${userId} → Test ${testId}, Variant ${variant}, Result: ${result}`);
};

export const logCampaignInteraction = async ({ campaignId, userId, interactionType, timestamp }) => {
  console.log(`[Campaign] ${userId} interacted with ${campaignId} via ${interactionType}`);
};

export const getUserLoyaltyTier = async (userId) => {
  return { tier: 'Gold', benefits: ['Free shipping', '5% discount'] };
};

export const getUserSubscriptions = async (userId) => {
  return [
    { kitId: 'kit_burn', frequency: 'monthly', nextShipment: new Date().toISOString() },
    { kitId: 'kit_trauma', frequency: 'quarterly', nextShipment: new Date(Date.now() + 7776000000).toISOString() }
  ];
};

export const getUIPersonalization = async (userId) => {
  return {
    layout: 'grid',
    theme: 'dark',
    recommendedKits: ['kit_burn', 'kit_emergency', 'kit_postop']
  };
};
