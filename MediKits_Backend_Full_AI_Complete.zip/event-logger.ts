
type EventPayload = Record<string, any>;

export interface Event {
  id: string;
  type: string;
  timestamp: number;
  payload: EventPayload;
}

const eventStore: Event[] = [];

export function emitEvent(type: string, payload: EventPayload): Event {
  const event: Event = {
    id: Math.random().toString(36).substring(2),
    type,
    timestamp: Date.now(),
    payload
  };
  eventStore.push(event);
  console.log(`[EVENT] ${type} emitted:`, payload);
  return event;
}

export function getEvents(): Event[] {
  return eventStore;
}
