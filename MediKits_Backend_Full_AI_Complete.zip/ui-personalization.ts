
import express from 'express';
import { storage } from './storage';

const router = express.Router();

// Get UI personalization settings for a user
router.get('/ui/preferences/:userId', async (req, res) => {
  const { userId } = req.params;
  try {
    const preferences = await storage.getUIPersonalization(userId);
    res.json({ success: true, preferences });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch UI preferences' });
  }
});

// Update UI personalization settings
router.post('/ui/preferences/:userId', async (req, res) => {
  const { userId } = req.params;
  const { layout, theme, recommendedKits } = req.body;
  try {
    const preferences = {
      layout: layout || 'grid',
      theme: theme || 'light',
      recommendedKits: recommendedKits || []
    };
    // Simulate update in memory
    res.json({ success: true, preferences });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update UI preferences' });
  }
});

export default router;
