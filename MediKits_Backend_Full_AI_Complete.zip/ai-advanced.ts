
import express from 'express';

const router = express.Router();

// Dummy DB counters (replace with real queries)
let totalOrders = 132;
let totalUsers = 68;

// 1. Churn Risk & CLV Predictor
router.get('/ai/churn-risk/:userId', (req, res) => {
  const { userId } = req.params;

  if (totalOrders < 100 || totalUsers < 50) {
    return res.json({ message: 'Not enough data to predict churn or CLV yet.' });
  }

  const churnRisk = Math.random() * 0.4 + 0.1; // 10%–50%
  const clv = Math.round(150 + Math.random() * 500); // $150–$650

  res.json({ userId, churnRisk: parseFloat(churnRisk.toFixed(2)), clv });
});

// 2. AI SEO Generator (mocked)
router.post('/ai/generate-content', (req, res) => {
  const { kitName } = req.body;
  if (!kitName) return res.status(400).json({ error: 'kitName is required' });

  const openAIConfigured = false; // Set true if OPENAI_API_KEY exists

  if (!openAIConfigured) {
    return res.status(501).json({ message: 'OpenAI integration not configured yet.' });
  }

  // Placeholder output
  res.json({
    name: kitName,
    seoTitle: `Buy ${kitName} - Certified & Fast Shipping`,
    tags: ['emergency', 'hospital', 'care'],
    faq: [
      { q: `What is included in the ${kitName}?`, a: 'It includes essentials for treatment.' }
    ]
  });
});

// 3. Kit Bundling Optimizer
router.get('/ai/bundle-suggestions', (req, res) => {
  if (totalOrders < 100) {
    return res.json({ message: 'Insufficient sales data for bundling optimization.' });
  }

  const bundles = [
    { main: 'Trauma Kit', bundledWith: 'Burn Recovery Kit' },
    { main: 'Ortho Kit', bundledWith: 'Cosmetic Post-Care Kit' }
  ];
  res.json({ suggestions: bundles });
});

export default router;
