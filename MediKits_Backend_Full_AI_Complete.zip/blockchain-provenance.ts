
import express from 'express';
import crypto from 'crypto';

const router = express.Router();
const provenanceLedger: Record<string, any[]> = {};

router.post('/blockchain/provenance', (req, res) => {
  const { kitId, supplier, metadata } = req.body;
  if (!kitId || !supplier) {
    return res.status(400).json({ error: 'kitId and supplier are required' });
  }

  const record = {
    timestamp: Date.now(),
    supplier,
    metadata,
    hash: crypto.createHash('sha256').update(kitId + supplier + Date.now()).digest('hex')
  };

  if (!provenanceLedger[kitId]) {
    provenanceLedger[kitId] = [];
  }
  provenanceLedger[kitId].push(record);

  res.json({ message: 'Provenance recorded', record });
});

router.get('/blockchain/provenance/:kitId', (req, res) => {
  const { kitId } = req.params;
  const records = provenanceLedger[kitId] || [];
  res.json({ kitId, provenance: records });
});

export default router;
