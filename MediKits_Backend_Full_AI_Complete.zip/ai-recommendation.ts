
import express from 'express';
import { storage } from './storage';

const router = express.Router();

router.post('/ai/recommend-products/:userId', async (req, res) => {
  const { userId } = req.params;

  try {
    const profile = await storage.getCustomerProfile(userId);
    const allProducts = await storage.getAllProducts();
    const recommendations = allProducts.filter(p =>
      profile.preferredCategories.includes(p.category)
    ).slice(0, 5);

    res.json({ recommended: recommendations });
  } catch (e) {
    res.status(500).json({ error: 'Could not generate recommendations' });
  }
});

export default router;
