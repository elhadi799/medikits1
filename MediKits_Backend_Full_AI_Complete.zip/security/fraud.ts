import crypto from 'crypto';
import speakeasy from 'speakeasy';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { storage } from '../storage';

export interface FraudDetectionResult {
  riskScore: number;
  patterns: string[];
  recommendations: string[];
  blocked: boolean;
}

export interface DeviceFingerprint {
  userAgent: string;
  ipAddress: string;
  timezone: string;
  language: string;
  screenResolution: string;
  hash: string;
}

// Main fraud detection function
export async function detectFraudPatterns(orderData: any): Promise<FraudDetectionResult> {
  let riskScore = 0;
  const patterns: string[] = [];
  const recommendations: string[] = [];

  // 1. High amount transaction detection
  const amount = parseFloat(orderData.totalAmount || '0');
  if (amount > 1000) {
    riskScore += 30;
    patterns.push('high_amount_transaction');
    recommendations.push('Verify payment method and identity');
  }

  // 2. Rapid successive orders (bot behavior)
  if (orderData.userId) {
    const recentOrders = await storage.getOrdersByUser(orderData.userId);
    const lastHourOrders = recentOrders.filter(order => 
      new Date(order.createdAt!).getTime() > Date.now() - 3600000
    );

    if (lastHourOrders.length > 3) {
      riskScore += 40;
      patterns.push('rapid_successive_orders');
      recommendations.push('Implement rate limiting and CAPTCHA verification');
    }
  }

  // 3. Suspicious IP analysis
  if (orderData.ipAddress) {
    const suspiciousIpPatterns = [
      /^10\./, // Private IP
      /^192\.168\./, // Private IP
      /^172\.(1[6-9]|2[0-9]|3[0-1])\./, // Private IP
      /proxy/i,
      /vpn/i,
      /tor/i
    ];

    const isSuspiciousIp = suspiciousIpPatterns.some(pattern => 
      pattern.test(orderData.ipAddress)
    );

    if (isSuspiciousIp) {
      riskScore += 25;
      patterns.push('suspicious_ip');
      recommendations.push('Verify customer location and identity');
    }
  }

  // 4. Device fingerprint analysis
  if (orderData.deviceFingerprint) {
    const knownFraudulentDevices = await checkDeviceFraudHistory(orderData.deviceFingerprint);
    if (knownFraudulentDevices.length > 0) {
      riskScore += 50;
      patterns.push('known_fraudulent_device');
      recommendations.push('Block device and require additional verification');
    }
  }

  // 5. Suspicious click patterns
  if (orderData.clickPatterns) {
    const suspiciousClicks = analyzeSuspiciousClicks(orderData.clickPatterns);
    if (suspiciousClicks.isSuspicious) {
      riskScore += suspiciousClicks.riskIncrease;
      patterns.push('suspicious_click_pattern');
      recommendations.push('Implement behavioral analytics');
    }
  }

  // 6. Payment method validation
  if (orderData.paymentMethod === 'cryptocurrency' || orderData.paymentMethod === 'gift_card') {
    riskScore += 20;
    patterns.push('high_risk_payment_method');
    recommendations.push('Additional verification required for alternative payment methods');
  }

  // 7. Address verification
  if (orderData.shippingAddress && orderData.billingAddress) {
    const addressMismatch = !addressesMatch(orderData.shippingAddress, orderData.billingAddress);
    if (addressMismatch) {
      riskScore += 15;
      patterns.push('address_mismatch');
      recommendations.push('Verify shipping and billing addresses');
    }
  }

  // Log security alert if high risk
  if (riskScore > 50) {
    await storage.createSecurityAlert({
      alertType: 'fraud_detection',
      severity: riskScore > 75 ? 'high' : 'medium',
      description: `High fraud risk detected: ${patterns.join(', ')}`,
      userId: orderData.userId,
      ipAddress: orderData.ipAddress,
      deviceFingerprint: orderData.deviceFingerprint,
      riskScore: riskScore / 100,
      actionTaken: riskScore > 75 ? 'order_blocked' : 'manual_review_required'
    });
  }

  return {
    riskScore: Math.min(riskScore, 100),
    patterns,
    recommendations,
    blocked: riskScore > 75
  };
}

// Bot behavior detection
export function detectBotBehavior(userActivity: any): boolean {
  const { pageViews, timeOnSite, clickPattern, mouseMovements } = userActivity;

  // Typical bot indicators
  const indicators = [
    timeOnSite < 10, // Too fast navigation
    clickPattern?.uniformTiming === true, // Uniform click intervals
    !mouseMovements || mouseMovements.length === 0, // No mouse movements
    pageViews?.length > 20 && timeOnSite < 60, // Too many pages too quickly
    userActivity.userAgent?.includes('bot') || userActivity.userAgent?.includes('crawler')
  ];

  return indicators.filter(Boolean).length >= 2;
}

// Suspicious click pattern analysis
function analyzeSuspiciousClicks(clickPatterns: any): { isSuspicious: boolean; riskIncrease: number } {
  if (!clickPatterns || !Array.isArray(clickPatterns)) {
    return { isSuspicious: false, riskIncrease: 0 };
  }

  let suspiciousFactors = 0;

  // Check for uniform timing (bot-like behavior)
  const timeDiffs = clickPatterns.slice(1).map((click: any, i: number) => 
    click.timestamp - clickPatterns[i].timestamp
  );
  
  const avgTimeDiff = timeDiffs.reduce((sum: number, diff: number) => sum + diff, 0) / timeDiffs.length;
  const uniformTiming = timeDiffs.every((diff: number) => Math.abs(diff - avgTimeDiff) < 50);
  
  if (uniformTiming) suspiciousFactors += 20;

  // Check for too rapid clicking
  const rapidClicks = timeDiffs.filter((diff: number) => diff < 100).length;
  if (rapidClicks > timeDiffs.length * 0.3) suspiciousFactors += 15;

  // Check for clicks without page navigation
  const noNavigation = clickPatterns.every((click: any) => !click.pageChange);
  if (noNavigation && clickPatterns.length > 10) suspiciousFactors += 25;

  return {
    isSuspicious: suspiciousFactors > 20,
    riskIncrease: suspiciousFactors
  };
}

// Check device fraud history
async function checkDeviceFraudHistory(deviceFingerprint: string): Promise<any[]> {
  try {
    const alerts = await storage.getSecurityAlerts(100);
    return alerts.filter(alert => 
      alert.deviceFingerprint === deviceFingerprint && 
      alert.alertType === 'fraud_detection'
    );
  } catch (error) {
    console.error('Error checking device fraud history:', error);
    return [];
  }
}

// Address comparison utility
function addressesMatch(shipping: any, billing: any): boolean {
  if (!shipping || !billing) return false;
  
  const normalizeAddress = (addr: any) => {
    const str = `${addr.street || ''} ${addr.city || ''} ${addr.state || ''} ${addr.zipCode || ''}`;
    return str.toLowerCase().replace(/[^a-z0-9]/g, '');
  };

  return normalizeAddress(shipping) === normalizeAddress(billing);
}

// Generate device fingerprint
export function generateDeviceFingerprint(req: any): DeviceFingerprint {
  const userAgent = req.headers['user-agent'] || '';
  const ipAddress = req.ip || req.connection.remoteAddress || '';
  const acceptLanguage = req.headers['accept-language'] || '';
  
  // Create a hash of the fingerprint components
  const fingerprintData = `${userAgent}|${ipAddress}|${acceptLanguage}`;
  const hash = crypto.createHash('sha256').update(fingerprintData).digest('hex');

  return {
    userAgent,
    ipAddress,
    timezone: req.headers['timezone'] || '',
    language: acceptLanguage.split(',')[0] || '',
    screenResolution: req.headers['screen-resolution'] || '',
    hash
  };
}

// Two-Factor Authentication functions
export function generateTwoFactorSecret(): { secret: string; qrCode: string } {
  const secret = speakeasy.generateSecret({
    name: 'Medical Kit Store',
    issuer: 'MedKit',
    length: 32
  });

  return {
    secret: secret.base32,
    qrCode: secret.otpauth_url || ''
  };
}

export function verifyTwoFactorToken(secret: string, token: string): boolean {
  return speakeasy.totp.verify({
    secret,
    encoding: 'base32',
    token,
    window: 2 // Allow 2 time steps
  });
}

// Password hashing and verification
export async function hashPassword(password: string): Promise<string> {
  const saltRounds = 12;
  return await bcrypt.hash(password, saltRounds);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return await bcrypt.compare(password, hash);
}

// JWT token functions
export function generateJWT(userId: number, role: string): string {
  const secret = process.env.JWT_SECRET || 'default-secret-change-this';
  return jwt.sign(
    { userId, role, iat: Math.floor(Date.now() / 1000) },
    secret,
    { expiresIn: '24h' }
  );
}

export function verifyJWT(token: string): any {
  const secret = process.env.JWT_SECRET || 'default-secret-change-this';
  try {
    return jwt.verify(token, secret);
  } catch (error) {
    throw new Error('Invalid token');
  }
}

// Data encryption for GDPR/CCPA compliance
export function encryptSensitiveData(data: string): string {
  const algorithm = 'aes-256-gcm';
  const secret = process.env.ENCRYPTION_KEY || 'default-key-change-this-to-32-chars';
  const iv = crypto.randomBytes(16);
  
  const cipher = crypto.createCipher(algorithm, secret);
  let encrypted = cipher.update(data, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  
  return `${iv.toString('hex')}:${encrypted}`;
}

export function decryptSensitiveData(encryptedData: string): string {
  const algorithm = 'aes-256-gcm';
  const secret = process.env.ENCRYPTION_KEY || 'default-key-change-this-to-32-chars';
  
  const [ivHex, encrypted] = encryptedData.split(':');
  const iv = Buffer.from(ivHex, 'hex');
  
  const decipher = crypto.createDecipher(algorithm, secret);
  let decrypted = decipher.update(encrypted, 'hex', 'utf8');
  decrypted += decipher.final('utf8');
  
  return decrypted;
}

// IP-based risk assessment
export function assessIpRisk(ipAddress: string): { riskLevel: string; score: number } {
  // Basic IP risk assessment (can be enhanced with external threat intel)
  let score = 0;
  let riskLevel = 'low';

  // Check for private/internal IPs
  if (ipAddress.startsWith('10.') || ipAddress.startsWith('192.168.') || 
      ipAddress.startsWith('172.')) {
    score += 20;
    riskLevel = 'medium';
  }

  // Check for localhost
  if (ipAddress === '127.0.0.1' || ipAddress === '::1') {
    score += 30;
    riskLevel = 'medium';
  }

  // Check for known proxy/VPN ranges (simplified)
  const suspiciousRanges = ['185.', '46.', '91.'];
  if (suspiciousRanges.some(range => ipAddress.startsWith(range))) {
    score += 25;
    riskLevel = 'medium';
  }

  if (score > 40) riskLevel = 'high';

  return { riskLevel, score };
}