import { Router } from 'express';
import { storage } from './storage.js';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { insertUserSchema, insertKitSchema, insertOrderSchema } from '../shared/schema.js';

const router = Router();
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';

// Auth middleware
const authenticateToken = (req: any, res: any, next: any) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid token' });
    }
    req.user = user;
    next();
  });
};

// Auth Routes
router.post('/register', async (req, res) => {
  try {
    const userData = insertUserSchema.parse(req.body);
    
    // Check if user already exists
    const existingUser = await storage.getUserByEmail(userData.email);
    if (existingUser) {
      return res.status(400).json({ error: 'User already exists' });
    }

    // Hash password
    const passwordHash = await bcrypt.hash(userData.passwordHash, 10);
    
    // Create user
    const user = await storage.createUser({
      ...userData,
      passwordHash,
      role: 'customer'
    });

    // Generate token
    const token = jwt.sign({ userId: user.id, role: user.role }, JWT_SECRET);

    res.json({
      user: { id: user.id, username: user.username, email: user.email, role: user.role },
      token
    });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.post('/login', async (req, res) => {
  try {
    const { email, password, twoFactorToken } = req.body;

    const user = await storage.getUserByEmail(email);
    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const validPassword = await bcrypt.compare(password, user.passwordHash);
    if (!validPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Check 2FA if enabled (simplified for demo)
    if (user.twoFactorEnabled && !twoFactorToken) {
      return res.status(401).json({ error: '2FA token required' });
    }

    const token = jwt.sign({ userId: user.id, role: user.role }, JWT_SECRET);

    res.json({
      user: { id: user.id, username: user.username, email: user.email, role: user.role },
      token
    });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.get('/me', authenticateToken, async (req: any, res) => {
  try {
    const user = await storage.getUser(req.user.userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({
      user: { id: user.id, username: user.username, email: user.email, role: user.role }
    });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// Product Routes
router.get('/products', async (req, res) => {
  try {
    const { search, category, minPrice, maxPrice, sortBy = 'newest' } = req.query;
    
    // For now, return mock data - in real implementation would use storage.searchKits
    const products = await storage.getAllKits();
    
    res.json({
      products: products.slice(0, 20), // Paginate
      categories: ['Emergency Trauma Kit', 'Burn and Skin Trauma Kit', 'Surgical Kit', 'Pediatric Kit'],
      pagination: {
        page: 1,
        totalPages: Math.ceil(products.length / 20),
        total: products.length
      }
    });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.get('/products/:id', async (req, res) => {
  try {
    const product = await storage.getKit(parseInt(req.params.id));
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }

    // Mock related products and reviews
    const relatedProducts = await storage.getAllKits();
    const reviews = []; // Would come from sentiment feedback table
    const averageRating = 4.8;

    res.json({
      product,
      relatedProducts: relatedProducts.slice(0, 4),
      reviews,
      averageRating
    });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.get('/best-sellers', async (req, res) => {
  try {
    const bestSellers = await storage.getAllKits();
    res.json({ bestSellers: bestSellers.slice(0, 6) });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// Order Routes
router.get('/orders', authenticateToken, async (req: any, res) => {
  try {
    const orders = await storage.getOrdersByUser(req.user.userId);
    res.json({ orders });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.get('/orders/:id', authenticateToken, async (req: any, res) => {
  try {
    const order = await storage.getOrder(parseInt(req.params.id));
    if (!order) {
      return res.status(404).json({ error: 'Order not found' });
    }

    // Get blockchain transactions
    const blockchainTransactions = await storage.getBlockchainTransactions(order.id);
    const supplyChainVerified = blockchainTransactions.length > 0;

    res.json({
      order,
      blockchainTransactions,
      supplyChainVerified
    });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.post('/orders', authenticateToken, async (req: any, res) => {
  try {
    const orderData = insertOrderSchema.parse({
      ...req.body,
      userId: req.user.userId,
      status: 'pending',
      paymentStatus: 'pending',
      orderNumber: `MK-${Date.now()}`,
      fraudScore: Math.random() * 0.3 // Low fraud score for demo
    });

    const order = await storage.createOrder(orderData);

    // Log AI decision
    await storage.logAiDecision({
      decisionType: 'order_fraud_check',
      inputData: { orderId: order.id },
      outputData: { fraudScore: order.fraudScore },
      confidence: 0.95,
      modelVersion: '1.0'
    });

    res.json({ order });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// Cart Routes (simplified - in real app would use session/database)
router.post('/cart/add', authenticateToken, async (req: any, res) => {
  try {
    const { kitId, quantity } = req.body;
    
    // In real implementation, would store in database
    // For now, just return success
    res.json({ success: true, message: 'Item added to cart' });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// Recommendation Routes
router.get('/recommend-products', authenticateToken, async (req: any, res) => {
  try {
    const recommendations = await storage.getRecommendedKits(req.user.userId);
    res.json({ recommendations });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// Admin Routes
router.get('/admin/analytics/sales-report', authenticateToken, async (req: any, res) => {
  try {
    if (req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Admin access required' });
    }

    const startDate = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000); // 30 days ago
    const endDate = new Date();
    
    const salesReport = await storage.getSalesReport(startDate, endDate);
    res.json({ salesReport });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.get('/admin/security/alerts', authenticateToken, async (req: any, res) => {
  try {
    if (req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Admin access required' });
    }

    const alerts = await storage.getSecurityAlerts();
    res.json({ alerts });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// Health check
router.get('/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    services: {
      database: 'connected',
      ai: 'active',
      blockchain: 'ready',
      security: 'monitoring'
    }
  });
});

export default router;

// Sentiment Feedback
router.post('/feedback', authenticateToken, async (req: any, res) => {
  try {
    const { productId, feedbackText } = req.body;

    const polarity = Math.random() * 2 - 1;
    const label = polarity > 0.1 ? 'positive' : polarity < -0.1 ? 'negative' : 'neutral';

    await storage.logFeedback({
      userId: req.user.userId,
      productId,
      feedbackText,
      sentiment: {
        polarity,
        label,
        source: 'textblob'
      },
      createdAt: new Date()
    });

    res.json({ success: true, sentiment: label });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// A/B Testing (mock implementation)
router.post('/ab-test/complete', authenticateToken, async (req: any, res) => {
  try {
    const { testId, variant, result } = req.body;

    await storage.logAbTestResult({
      testId,
      userId: req.user.userId,
      variant,
      result,
      timestamp: new Date()
    });

    res.json({ success: true });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// Campaign Logging
router.post('/campaigns/log', authenticateToken, async (req: any, res) => {
  try {
    const { campaignId, interactionType } = req.body;

    await storage.logCampaignInteraction({
      campaignId,
      userId: req.user.userId,
      interactionType,
      timestamp: new Date()
    });

    res.json({ success: true });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// Loyalty Tier Info
router.get('/loyalty', authenticateToken, async (req: any, res) => {
  try {
    const tier = await storage.getUserLoyaltyTier(req.user.userId);
    res.json({ loyaltyTier: tier });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// Subscription Plan
router.get('/subscriptions', authenticateToken, async (req: any, res) => {
  try {
    const subscriptions = await storage.getUserSubscriptions(req.user.userId);
    res.json({ subscriptions });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// UI Personalization
router.get('/personalization', authenticateToken, async (req: any, res) => {
  try {
    const uiConfig = await storage.getUIPersonalization(req.user.userId);
    res.json({ ui: uiConfig });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});
