
import express from 'express';
import { SentimentAnalyzer } from 'node-nlp';

const router = express.Router();
const analyzer = new SentimentAnalyzer({ language: 'en' });

router.post('/ai/sentiment', async (req, res) => {
  const { text } = req.body;
  if (!text) return res.status(400).json({ error: 'Text is required' });

  const result = await analyzer.getSentiment(text);
  const score = result.score;
  let emotion = 'neutral';
  if (score > 0.4) emotion = 'positive';
  else if (score < -0.4) emotion = 'negative';

  res.json({ score, emotion });
});

export default router;
