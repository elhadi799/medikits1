import { 
  type User, type InsertUser, type Kit, type InsertKit, type Order, type InsertOrder,
  type CustomerProfile, type InsertCustomerProfile, type AiDecisionLog, type InsertAiDecisionLog,
  type SecurityAlert, type InsertSecurityAlert, type SentimentFeedback, type InsertSentimentFeedback,
  type SmartContract, type InsertSmartContract, type BlockchainTransaction, type InsertBlockchainTransaction,
  type UiPersonalization, type InsertUiPersonalization, type CampaignLog, type InsertCampaignLog,
  type AffiliateProfile, type InsertAffiliateProfile, type AnalyticsEvent, type InsertAnalyticsEvent
} from "../shared/schema.js";

export interface IStorage {
  // User Management
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(insertUser: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;
  
  // Customer Profiles
  getCustomerProfile(userId: number): Promise<CustomerProfile | undefined>;
  createCustomerProfile(profile: InsertCustomerProfile): Promise<CustomerProfile>;
  updateCustomerProfile(userId: number, updates: Partial<CustomerProfile>): Promise<CustomerProfile | undefined>;
  
  // Kit Management
  getAllKits(): Promise<Kit[]>;
  getKit(id: number): Promise<Kit | undefined>;
  getKitsByCategory(category: string): Promise<Kit[]>;
  createKit(insertKit: InsertKit): Promise<Kit>;
  updateKit(id: number, updates: Partial<Kit>): Promise<Kit | undefined>;
  searchKits(query: string): Promise<Kit[]>;
  getRecommendedKits(userId: number, limit?: number): Promise<Kit[]>;
  
  // Order Management
  getOrder(id: number): Promise<Order | undefined>;
  getOrdersByUser(userId: number): Promise<Order[]>;
  createOrder(insertOrder: InsertOrder): Promise<Order>;
  updateOrder(id: number, updates: Partial<Order>): Promise<Order | undefined>;
  getOrdersByStatus(status: string): Promise<Order[]>;
  
  // AI & Analytics
  logAiDecision(log: InsertAiDecisionLog): Promise<AiDecisionLog>;
  getAiDecisionsByType(decisionType: string, limit?: number): Promise<AiDecisionLog[]>;
  getAiPerformanceFeedback(week: number): Promise<any>;
  
  // Security & Fraud
  createSecurityAlert(alert: InsertSecurityAlert): Promise<SecurityAlert>;
  getSecurityAlerts(limit?: number): Promise<SecurityAlert[]>;
  detectFraudPatterns(orderData: any): Promise<{ riskScore: number; patterns: string[] }>;
  
  // Sentiment & Feedback
  createSentimentFeedback(feedback: InsertSentimentFeedback): Promise<SentimentFeedback>;
  getSentimentByKit(kitId: number): Promise<SentimentFeedback[]>;
  
  // Blockchain Integration
  createSmartContract(contract: InsertSmartContract): Promise<SmartContract>;
  createBlockchainTransaction(transaction: InsertBlockchainTransaction): Promise<BlockchainTransaction>;
  getBlockchainTransactions(orderId: number): Promise<BlockchainTransaction[]>;
  
  // Personalization
  getUiPersonalization(userId: number): Promise<UiPersonalization | undefined>;
  updateUiPersonalization(userId: number, preferences: InsertUiPersonalization): Promise<UiPersonalization>;
  
  // Campaign Management
  createCampaignLog(campaign: InsertCampaignLog): Promise<CampaignLog>;
  getCampaignsByUser(userId: number): Promise<CampaignLog[]>;
  
  // Affiliate Management
  getAffiliateProfile(userId: number): Promise<AffiliateProfile | undefined>;
  createAffiliateProfile(profile: InsertAffiliateProfile): Promise<AffiliateProfile>;
  
  // Analytics
  logAnalyticsEvent(event: InsertAnalyticsEvent): Promise<AnalyticsEvent>;
  getAnalyticsByType(eventType: string, startDate: Date, endDate: Date): Promise<AnalyticsEvent[]>;
  getSalesReport(startDate: Date, endDate: Date): Promise<any>;
}

// For demo purposes, using in-memory storage instead of database
export class MemoryStorage implements IStorage {
  private users: User[] = [
    {
      id: 1,
      username: 'admin',
      email: 'admin@medkit.com',
      passwordHash: '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', // password123
      role: 'admin',
      twoFactorEnabled: false,
      lastLoginAt: new Date(),
      createdAt: new Date(),
      updatedAt: new Date()
    },
    {
      id: 2, 
      username: 'doctor',
      email: 'doctor@hospital.com', 
      passwordHash: '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', // password123
      role: 'customer',
      twoFactorEnabled: false,
      lastLoginAt: new Date(),
      createdAt: new Date(),
      updatedAt: new Date()
    }
  ];

  private kits: Kit[] = [
    {
      id: 1,
      name: 'Emergency Trauma Kit',
      description: 'Complete emergency medical kit for trauma situations. Contains essential supplies for treating severe injuries in emergency situations including bandages, antiseptics, splints, and emergency medications.',
      category: 'Emergency Trauma Kit',
      basePrice: 299.99,
      currentPrice: 299.99,
      stockLevel: 150,
      minimumThreshold: 25,
      specifications: {
        weight: '5.2 lbs',
        dimensions: '14x10x6 inches',
        components: '87 items',
        certification: 'FDA Approved',
        shelfLife: '5 years',
        temperature: 'Store at 15-25°C'
      },
      imageUrl: '/api/placeholder/400/300',
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date()
    },
    {
      id: 2,
      name: 'Burn and Skin Trauma Kit',
      description: 'Specialized kit for treating burns and skin trauma. Professional-grade supplies for burn care and wound management including cooling gels, sterile dressings, and pain relief.',
      category: 'Burn and Skin Trauma Kit',
      basePrice: 189.99,
      currentPrice: 179.99,
      stockLevel: 95,
      minimumThreshold: 20,
      specifications: {
        weight: '3.8 lbs',
        dimensions: '12x8x4 inches',
        components: '64 items',
        certification: 'FDA Approved',
        shelfLife: '3 years',
        temperature: 'Store at 15-25°C'
      },
      imageUrl: '/api/placeholder/400/300',
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date()
    },
    {
      id: 3,
      name: 'Surgical Prep Kit',
      description: 'Complete surgical preparation kit with sterile instruments and supplies for minor surgical procedures. Includes scalpels, forceps, sutures, and sterilization materials.',
      category: 'Surgical Kit',
      basePrice: 449.99,
      currentPrice: 449.99,
      stockLevel: 75,
      minimumThreshold: 15,
      specifications: {
        weight: '7.1 lbs',
        dimensions: '16x12x8 inches',
        components: '156 items',
        certification: 'FDA Approved, CE Marked',
        shelfLife: '2 years',
        temperature: 'Store at 15-25°C'
      },
      imageUrl: '/api/placeholder/400/300',
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date()
    },
    {
      id: 4,
      name: 'Pediatric Emergency Kit',
      description: 'Specialized emergency kit designed for pediatric patients. Contains age-appropriate supplies and medications for treating children in emergency situations.',
      category: 'Pediatric Kit',
      basePrice: 249.99,
      currentPrice: 229.99,
      stockLevel: 85,
      minimumThreshold: 20,
      specifications: {
        weight: '4.5 lbs',
        dimensions: '13x9x5 inches',
        components: '78 items',
        certification: 'FDA Approved',
        ageRange: '0-12 years',
        shelfLife: '4 years'
      },
      imageUrl: '/api/placeholder/400/300',
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date()
    }
  ];

  private orders: Order[] = [];
  private aiDecisionLogs: AiDecisionLog[] = [];
  private securityAlerts: SecurityAlert[] = [];
  private blockchainTransactions: BlockchainTransaction[] = [];
  
  private nextUserId = 3;
  private nextKitId = 5;
  private nextOrderId = 1;

  // User Management
  async getUser(id: number): Promise<User | undefined> {
    return this.users.find(u => u.id === id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return this.users.find(u => u.username === username);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return this.users.find(u => u.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const user: User = {
      id: this.nextUserId++,
      ...insertUser,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.users.push(user);
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const index = this.users.findIndex(u => u.id === id);
    if (index === -1) return undefined;
    
    this.users[index] = { ...this.users[index], ...updates, updatedAt: new Date() };
    return this.users[index];
  }

  // Customer Profiles (simplified)
  async getCustomerProfile(userId: number): Promise<CustomerProfile | undefined> {
    return undefined; // Not implemented for demo
  }

  async createCustomerProfile(profile: InsertCustomerProfile): Promise<CustomerProfile> {
    throw new Error('Not implemented');
  }

  async updateCustomerProfile(userId: number, updates: Partial<CustomerProfile>): Promise<CustomerProfile | undefined> {
    return undefined;
  }

  // Kit Management
  async getAllKits(): Promise<Kit[]> {
    return this.kits.filter(k => k.isActive);
  }

  async getKit(id: number): Promise<Kit | undefined> {
    return this.kits.find(k => k.id === id && k.isActive);
  }

  async getKitsByCategory(category: string): Promise<Kit[]> {
    return this.kits.filter(k => k.category === category && k.isActive);
  }

  async createKit(insertKit: InsertKit): Promise<Kit> {
    const kit: Kit = {
      id: this.nextKitId++,
      ...insertKit,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.kits.push(kit);
    return kit;
  }

  async updateKit(id: number, updates: Partial<Kit>): Promise<Kit | undefined> {
    const index = this.kits.findIndex(k => k.id === id);
    if (index === -1) return undefined;
    
    this.kits[index] = { ...this.kits[index], ...updates, updatedAt: new Date() };
    return this.kits[index];
  }

  async searchKits(query: string): Promise<Kit[]> {
    const lowerQuery = query.toLowerCase();
    return this.kits.filter(k => 
      k.isActive && (
        k.name.toLowerCase().includes(lowerQuery) ||
        k.description.toLowerCase().includes(lowerQuery) ||
        k.category.toLowerCase().includes(lowerQuery)
      )
    );
  }

  async getRecommendedKits(userId: number, limit = 6): Promise<Kit[]> {
    return this.kits.filter(k => k.isActive).slice(0, limit);
  }

  // Order Management
  async getOrder(id: number): Promise<Order | undefined> {
    return this.orders.find(o => o.id === id);
  }

  async getOrdersByUser(userId: number): Promise<Order[]> {
    return this.orders.filter(o => o.userId === userId);
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const order: Order = {
      id: this.nextOrderId++,
      ...insertOrder,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.orders.push(order);
    return order;
  }

  async updateOrder(id: number, updates: Partial<Order>): Promise<Order | undefined> {
    const index = this.orders.findIndex(o => o.id === id);
    if (index === -1) return undefined;
    
    this.orders[index] = { ...this.orders[index], ...updates, updatedAt: new Date() };
    return this.orders[index];
  }

  async getOrdersByStatus(status: string): Promise<Order[]> {
    return this.orders.filter(o => o.status === status);
  }

  // AI & Analytics
  async logAiDecision(log: InsertAiDecisionLog): Promise<AiDecisionLog> {
    const decision: AiDecisionLog = {
      id: this.aiDecisionLogs.length + 1,
      ...log,
      createdAt: new Date()
    };
    this.aiDecisionLogs.push(decision);
    return decision;
  }

  async getAiDecisionsByType(decisionType: string, limit = 100): Promise<AiDecisionLog[]> {
    return this.aiDecisionLogs
      .filter(d => d.decisionType === decisionType)
      .slice(0, limit);
  }

  async getAiPerformanceFeedback(week: number): Promise<any> {
    return {
      accuracyScore: 0.95,
      totalDecisions: this.aiDecisionLogs.length,
      avgConfidence: 0.87
    };
  }

  // Security & Fraud
  async createSecurityAlert(alert: InsertSecurityAlert): Promise<SecurityAlert> {
    const securityAlert: SecurityAlert = {
      id: this.securityAlerts.length + 1,
      ...alert,
      createdAt: new Date(),
      resolvedAt: null
    };
    this.securityAlerts.push(securityAlert);
    return securityAlert;
  }

  async getSecurityAlerts(limit = 50): Promise<SecurityAlert[]> {
    return this.securityAlerts.slice(0, limit);
  }

  async detectFraudPatterns(orderData: any): Promise<{ riskScore: number; patterns: string[] }> {
    // Simplified fraud detection
    const riskScore = Math.random() * 0.3; // Low risk for demo
    const patterns: string[] = [];
    
    if (orderData.totalAmount > 1000) {
      patterns.push('high-value-transaction');
    }
    
    return { riskScore, patterns };
  }

  // Sentiment & Feedback (simplified)
  async createSentimentFeedback(feedback: InsertSentimentFeedback): Promise<SentimentFeedback> {
    throw new Error('Not implemented');
  }

  async getSentimentByKit(kitId: number): Promise<SentimentFeedback[]> {
    return [];
  }

  // Blockchain Integration
  async createSmartContract(contract: InsertSmartContract): Promise<SmartContract> {
    throw new Error('Not implemented');
  }

  async createBlockchainTransaction(transaction: InsertBlockchainTransaction): Promise<BlockchainTransaction> {
    const tx: BlockchainTransaction = {
      id: this.blockchainTransactions.length + 1,
      ...transaction,
      createdAt: new Date(),
      confirmedAt: null
    };
    this.blockchainTransactions.push(tx);
    return tx;
  }

  async getBlockchainTransactions(orderId: number): Promise<BlockchainTransaction[]> {
    return this.blockchainTransactions.filter(t => t.orderId === orderId);
  }

  // Other methods (simplified implementations)
  async getUiPersonalization(userId: number): Promise<UiPersonalization | undefined> {
    return undefined;
  }

  async updateUiPersonalization(userId: number, preferences: InsertUiPersonalization): Promise<UiPersonalization> {
    throw new Error('Not implemented');
  }

  async createCampaignLog(campaign: InsertCampaignLog): Promise<CampaignLog> {
    throw new Error('Not implemented');
  }

  async getCampaignsByUser(userId: number): Promise<CampaignLog[]> {
    return [];
  }

  async getAffiliateProfile(userId: number): Promise<AffiliateProfile | undefined> {
    return undefined;
  }

  async createAffiliateProfile(profile: InsertAffiliateProfile): Promise<AffiliateProfile> {
    throw new Error('Not implemented');
  }

  async logAnalyticsEvent(event: InsertAnalyticsEvent): Promise<AnalyticsEvent> {
    throw new Error('Not implemented');
  }

  async getAnalyticsByType(eventType: string, startDate: Date, endDate: Date): Promise<AnalyticsEvent[]> {
    return [];
  }

  async getSalesReport(startDate: Date, endDate: Date): Promise<any> {
    const totalSales = this.orders
      .filter(o => o.status === 'completed' || o.status === 'delivered')
      .reduce((sum, o) => sum + o.totalAmount, 0);
    
    return {
      totalSales,
      totalOrders: this.orders.length,
      period: `${startDate.toISOString().split('T')[0]} to ${endDate.toISOString().split('T')[0]}`
    };
  }
}

export const storage = new MemoryStorage();