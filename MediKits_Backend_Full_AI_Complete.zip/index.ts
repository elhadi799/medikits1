import express from 'express';
import cors from 'cors';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { createProxyMiddleware } from 'http-proxy-middleware';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());

// API Routes
import routes from './routes.js';
import uiRoutes from './ui-personalization';
import analyticsRoutes from './analytics-export';
import recommendationRoutes from './ai-recommendation';
import sentimentRoutes from './sentiment-analysis';
import kitRoutes from './kit-bundles';
import provenanceRoutes from './blockchain-provenance';
import advancedAiRoutes from './ai-advanced';
import extendedAiRoutes from './ai-extended';
app.use('/api', routes);
app.use('/api', uiRoutes);
app.use('/api', analyticsRoutes);
app.use('/api', recommendationRoutes);
app.use('/api', sentimentRoutes);
app.use('/api', kitRoutes);
app.use('/api', provenanceRoutes);
app.use('/api', advancedAiRoutes);
app.use('/api', extendedAiRoutes);

// In development, proxy to Vite dev server
if (process.env.NODE_ENV !== 'production') {
  app.use('/', createProxyMiddleware({
    target: 'http://localhost:5173',
    changeOrigin: true,
    ws: true,
  }));
} else {
  // Serve static files in production
  app.use(express.static(join(__dirname, '../client/dist')));
  
  // Handle client-side routing
  app.get('*', (req, res) => {
    res.sendFile(join(__dirname, '../client/dist/index.html'));
  });
}

app.listen(PORT, '0.0.0.0', () => {
  console.log(`🏥 Medical Kit Store server running on http://0.0.0.0:${PORT}`);
  console.log(`🤖 AI/ML services initialized`);
  console.log(`🔐 Security systems active`);
  console.log(`⛓️  Blockchain integration ready`);
});