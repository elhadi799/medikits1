
import { pgTable, text, varchar, timestamp, integer, real, serial } from 'drizzle-orm/pg-core';

export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  username: varchar('username', { length: 64 }).notNull().unique(),
  password: text('password').notNull(),
  role: varchar('role', { length: 20 }).default('customer')
});

export const kits = pgTable('kits', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 100 }).notNull(),
  category: varchar('category', { length: 50 }).notNull(),
  description: text('description'),
  price: real('price'),
  popularityScore: real('popularity_score').default(0)
});

export const orders = pgTable('orders', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id),
  totalAmount: real('total_amount'),
  status: varchar('status', { length: 20 }).default('pending'),
  createdAt: timestamp('created_at').defaultNow()
});

export const feedback = pgTable('feedback', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id),
  text: text('text'),
  sentimentScore: real('sentiment_score'),
  emotion: varchar('emotion', { length: 20 })
});

export const preferences = pgTable('preferences', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id),
  layout: varchar('layout', { length: 20 }),
  theme: varchar('theme', { length: 20 })
});
