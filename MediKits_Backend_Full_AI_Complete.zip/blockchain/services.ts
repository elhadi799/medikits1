import Web3 from 'web3';
import { storage } from '../storage';
import { v4 as uuidv4 } from 'uuid';

// Smart contract ABI for medical kit tracking
const MEDICAL_KIT_ABI = [
  {
    "inputs": [
      {"name": "_kitId", "type": "uint256"},
      {"name": "_orderId", "type": "uint256"},
      {"name": "_supplier", "type": "string"},
      {"name": "_metadata", "type": "string"}
    ],
    "name": "createKitProvenance",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [{"name": "_kitId", "type": "uint256"}],
    "name": "getKitProvenance",
    "outputs": [
      {"name": "supplier", "type": "string"},
      {"name": "timestamp", "type": "uint256"},
      {"name": "verified", "type": "bool"}
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {"name": "_kitId", "type": "uint256"},
      {"name": "_newOwner", "type": "address"}
    ],
    "name": "transferOwnership",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  }
];

const SUPPLY_CHAIN_BYTECODE = "608060405234801561001057600080fd5b50..."; // Smart contract bytecode

export interface BlockchainConfig {
  network: 'ethereum' | 'polygon' | 'localhost';
  rpcUrl: string;
  privateKey?: string;
  contractAddress?: string;
}

export interface ProvenanceData {
  kitId: number;
  orderId: number;
  supplier: string;
  timestamp: number;
  txHash: string;
  verified: boolean;
  metadata: any;
}

// Initialize Web3 connection
function initializeWeb3(config: BlockchainConfig): Web3 {
  const web3 = new Web3(config.rpcUrl);
  
  if (config.privateKey) {
    const account = web3.eth.accounts.privateKeyToAccount(config.privateKey);
    web3.eth.accounts.wallet.add(account);
    web3.eth.defaultAccount = account.address;
  }
  
  return web3;
}

// Deploy smart contract for medical kit tracking
export async function deploySmartContract(
  network: string = 'polygon',
  deployerPrivateKey?: string
): Promise<any> {
  try {
    const config: BlockchainConfig = {
      network: network as any,
      rpcUrl: getNetworkRpcUrl(network),
      privateKey: deployerPrivateKey || process.env.BLOCKCHAIN_PRIVATE_KEY
    };

    const web3 = initializeWeb3(config);
    
    if (!web3.eth.defaultAccount) {
      throw new Error('No account configured for deployment');
    }

    const contract = new web3.eth.Contract(MEDICAL_KIT_ABI);
    
    // Deploy contract
    const deployTx = contract.deploy({
      data: SUPPLY_CHAIN_BYTECODE,
      arguments: [] // Constructor arguments if any
    });

    const gas = await deployTx.estimateGas();
    const gasPrice = await web3.eth.getGasPrice();

    const deployment = await deployTx.send({
      from: web3.eth.defaultAccount,
      gas: gas.toString(),
      gasPrice: gasPrice.toString()
    });

    // Store contract information
    const smartContract = await storage.createSmartContract({
      contractAddress: deployment.options.address!,
      contractType: 'medical_kit_tracking',
      network,
      deploymentTxHash: deployment.transactionHash!,
      abi: MEDICAL_KIT_ABI,
      gasUsed: gas.toString()
    });

    return {
      contractAddress: deployment.options.address,
      transactionHash: deployment.transactionHash,
      gasUsed: gas.toString(),
      network,
      contractId: smartContract.id
    };
  } catch (error) {
    console.error('Smart contract deployment error:', error);
    throw error;
  }
}

// Create blockchain transaction for product provenance
export async function createBlockchainTransaction(
  orderId: number,
  kitId: number,
  supplier: string,
  metadata: any = {}
): Promise<ProvenanceData> {
  try {
    const config: BlockchainConfig = {
      network: 'polygon', // Default to Polygon for lower fees
      rpcUrl: getNetworkRpcUrl('polygon'),
      privateKey: process.env.BLOCKCHAIN_PRIVATE_KEY
    };

    const web3 = initializeWeb3(config);
    
    if (!web3.eth.defaultAccount) {
      throw new Error('No blockchain account configured');
    }

    // Get or deploy contract
    let contractAddress = process.env.SMART_CONTRACT_ADDRESS;
    if (!contractAddress) {
      const deployment = await deploySmartContract('polygon');
      contractAddress = deployment.contractAddress;
    }

    const contract = new web3.eth.Contract(MEDICAL_KIT_ABI, contractAddress);

    // Create provenance transaction
    const txData = contract.methods.createKitProvenance(
      kitId,
      orderId,
      supplier,
      JSON.stringify(metadata)
    );

    const gas = await txData.estimateGas({ from: web3.eth.defaultAccount });
    const gasPrice = await web3.eth.getGasPrice();

    const transaction = await txData.send({
      from: web3.eth.defaultAccount,
      gas: gas.toString(),
      gasPrice: gasPrice.toString()
    });

    // Store blockchain transaction
    const blockchainTx = await storage.createBlockchainTransaction({
      orderId,
      txHash: transaction.transactionHash!,
      fromAddress: web3.eth.defaultAccount,
      toAddress: contractAddress!,
      gasPrice: gasPrice.toString(),
      gasUsed: gas.toString(),
      blockNumber: transaction.blockNumber?.toString(),
      status: 'completed',
      transactionType: 'provenance_creation',
      metadata: {
        kitId,
        supplier,
        originalMetadata: metadata
      }
    });

    return {
      kitId,
      orderId,
      supplier,
      timestamp: Date.now(),
      txHash: transaction.transactionHash!,
      verified: true,
      metadata
    };
  } catch (error) {
    console.error('Blockchain transaction error:', error);
    throw error;
  }
}

// Verify product authenticity through blockchain
export async function verifyProductAuthenticity(kitId: number): Promise<ProvenanceData | null> {
  try {
    const contractAddress = process.env.SMART_CONTRACT_ADDRESS;
    if (!contractAddress) {
      throw new Error('Smart contract not deployed');
    }

    const config: BlockchainConfig = {
      network: 'polygon',
      rpcUrl: getNetworkRpcUrl('polygon'),
      contractAddress
    };

    const web3 = initializeWeb3(config);
    const contract = new web3.eth.Contract(MEDICAL_KIT_ABI, contractAddress);

    // Query blockchain for kit provenance
    const result = await contract.methods.getKitProvenance(kitId).call();

    if (result && result.supplier) {
      return {
        kitId,
        orderId: 0, // Not stored on-chain in this simple implementation
        supplier: result.supplier,
        timestamp: parseInt(result.timestamp),
        txHash: '', // Would need to be stored separately
        verified: result.verified,
        metadata: {}
      };
    }

    return null;
  } catch (error) {
    console.error('Product verification error:', error);
    return null;
  }
}

// Transfer ownership on blockchain
export async function transferKitOwnership(
  kitId: number,
  newOwnerAddress: string
): Promise<string> {
  try {
    const contractAddress = process.env.SMART_CONTRACT_ADDRESS;
    if (!contractAddress) {
      throw new Error('Smart contract not deployed');
    }

    const config: BlockchainConfig = {
      network: 'polygon',
      rpcUrl: getNetworkRpcUrl('polygon'),
      privateKey: process.env.BLOCKCHAIN_PRIVATE_KEY,
      contractAddress
    };

    const web3 = initializeWeb3(config);
    const contract = new web3.eth.Contract(MEDICAL_KIT_ABI, contractAddress);

    const txData = contract.methods.transferOwnership(kitId, newOwnerAddress);
    const gas = await txData.estimateGas({ from: web3.eth.defaultAccount });
    const gasPrice = await web3.eth.getGasPrice();

    const transaction = await txData.send({
      from: web3.eth.defaultAccount!,
      gas: gas.toString(),
      gasPrice: gasPrice.toString()
    });

    // Log the ownership transfer
    await storage.createBlockchainTransaction({
      txHash: transaction.transactionHash!,
      fromAddress: web3.eth.defaultAccount!,
      toAddress: newOwnerAddress,
      gasPrice: gasPrice.toString(),
      gasUsed: gas.toString(),
      blockNumber: transaction.blockNumber?.toString(),
      status: 'completed',
      transactionType: 'ownership_transfer',
      metadata: { kitId, newOwner: newOwnerAddress }
    });

    return transaction.transactionHash!;
  } catch (error) {
    console.error('Ownership transfer error:', error);
    throw error;
  }
}

// Get network RPC URL
function getNetworkRpcUrl(network: string): string {
  const networks = {
    ethereum: process.env.ETHEREUM_RPC_URL || 'https://mainnet.infura.io/v3/YOUR_PROJECT_ID',
    polygon: process.env.POLYGON_RPC_URL || 'https://polygon-rpc.com/',
    localhost: 'http://localhost:8545'
  };

  return networks[network as keyof typeof networks] || networks.polygon;
}

// Check transaction status
export async function checkTransactionStatus(txHash: string): Promise<any> {
  try {
    const config: BlockchainConfig = {
      network: 'polygon',
      rpcUrl: getNetworkRpcUrl('polygon')
    };

    const web3 = initializeWeb3(config);
    const receipt = await web3.eth.getTransactionReceipt(txHash);

    if (receipt) {
      return {
        status: receipt.status ? 'success' : 'failed',
        blockNumber: receipt.blockNumber,
        gasUsed: receipt.gasUsed,
        confirmations: await web3.eth.getBlockNumber() - receipt.blockNumber
      };
    }

    return { status: 'pending' };
  } catch (error) {
    console.error('Transaction status check error:', error);
    return { status: 'error', error: error.message };
  }
}

// Batch process multiple blockchain transactions
export async function batchProcessTransactions(transactions: any[]): Promise<any[]> {
  const results = [];

  for (const tx of transactions) {
    try {
      const result = await createBlockchainTransaction(
        tx.orderId,
        tx.kitId,
        tx.supplier,
        tx.metadata
      );
      results.push({ success: true, data: result });
    } catch (error) {
      results.push({ success: false, error: error.message, orderId: tx.orderId });
    }
  }

  return results;
}

// Get blockchain analytics
export async function getBlockchainAnalytics(period: number = 30): Promise<any> {
  try {
    const startDate = new Date(Date.now() - period * 24 * 60 * 60 * 1000);
    const endDate = new Date();

    // This would typically query your transaction database
    const transactions = await storage.getSalesReport(startDate, endDate);

    return {
      period: `${period} days`,
      totalTransactions: transactions.totalOrders || 0,
      totalValue: transactions.totalSales || 0,
      averageGasCost: '0.025', // Estimated
      successRate: 0.98, // Estimated
      popularNetwork: 'polygon',
      authenticityVerifications: Math.floor((transactions.totalOrders || 0) * 0.8)
    };
  } catch (error) {
    console.error('Blockchain analytics error:', error);
    return {};
  }
}

// Validate wallet address format
export function validateWalletAddress(address: string, network: string = 'ethereum'): boolean {
  try {
    const web3 = new Web3();
    return web3.utils.isAddress(address);
  } catch (error) {
    return false;
  }
}

// Generate blockchain wallet for user
export function generateWallet(): { address: string; privateKey: string; mnemonic?: string } {
  try {
    const web3 = new Web3();
    const account = web3.eth.accounts.create();
    
    return {
      address: account.address,
      privateKey: account.privateKey
    };
  } catch (error) {
    console.error('Wallet generation error:', error);
    throw error;
  }
}

// Smart contract interaction utilities
export class SmartContractManager {
  private web3: Web3;
  private contractAddress: string;
  private contract: any;

  constructor(contractAddress: string, network: string = 'polygon') {
    this.contractAddress = contractAddress;
    this.web3 = initializeWeb3({
      network: network as any,
      rpcUrl: getNetworkRpcUrl(network),
      privateKey: process.env.BLOCKCHAIN_PRIVATE_KEY
    });
    this.contract = new this.web3.eth.Contract(MEDICAL_KIT_ABI, contractAddress);
  }

  async callMethod(methodName: string, params: any[] = [], options: any = {}): Promise<any> {
    try {
      if (this.contract.methods[methodName]) {
        const method = this.contract.methods[methodName](...params);
        
        if (options.send) {
          const gas = await method.estimateGas({ from: this.web3.eth.defaultAccount });
          const gasPrice = await this.web3.eth.getGasPrice();
          
          return await method.send({
            from: this.web3.eth.defaultAccount,
            gas: gas.toString(),
            gasPrice: gasPrice.toString(),
            ...options
          });
        } else {
          return await method.call(options);
        }
      }
      throw new Error(`Method ${methodName} not found`);
    } catch (error) {
      console.error(`Smart contract method call error (${methodName}):`, error);
      throw error;
    }
  }

  async getEvents(eventName: string, fromBlock: number = 0): Promise<any[]> {
    try {
      return await this.contract.getPastEvents(eventName, {
        fromBlock,
        toBlock: 'latest'
      });
    } catch (error) {
      console.error(`Event query error (${eventName}):`, error);
      return [];
    }
  }
}